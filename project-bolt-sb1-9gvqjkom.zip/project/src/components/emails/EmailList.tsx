import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Search, Filter, Send, Check, AlertCircle } from 'lucide-react';
import Button from '../ui/Button';

const EmailList: React.FC = () => {
  const { emails } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'sent' | 'draft'>('all');

  const filteredEmails = emails.filter(email => {
    const matchesSearch = email.company.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          email.recipient.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    return matchesSearch && email.status === filter;
  });

  if (!emails.length) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 text-center">
        <p className="text-gray-600 mb-4">No emails have been generated yet.</p>
        <Button
          variant="primary"
          size="sm"
          onClick={() => window.location.href = '/dashboard'}
        >
          Go to Dashboard to Generate Emails
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Generated Emails</h2>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search emails..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 text-sm border rounded-md w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter className="h-4 w-4 text-gray-400" />
            </div>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as 'all' | 'sent' | 'draft')}
              className="pl-10 pr-4 py-2 text-sm border rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All</option>
              <option value="sent">Sent</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="space-y-4">
        {filteredEmails.map((email) => (
          <div 
            key={email.id} 
            className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
          >
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-medium text-gray-800">{email.company}</h3>
              <div className={`flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                email.status === 'sent' 
                  ? 'bg-green-100 text-green-800' 
                  : email.status === 'failed' 
                  ? 'bg-red-100 text-red-800'
                  : 'bg-blue-100 text-blue-800'
              }`}>
                {email.status === 'sent' && <Check className="h-3 w-3 mr-1" />}
                {email.status === 'failed' && <AlertCircle className="h-3 w-3 mr-1" />}
                {email.status === 'draft' && <Send className="h-3 w-3 mr-1" />}
                {email.status === 'sent' ? 'Sent' : email.status === 'failed' ? 'Failed' : 'Draft'}
              </div>
            </div>
            
            <div className="text-sm text-gray-500 mb-2">
              To: {email.recipient}
            </div>
            
            <div className="text-sm text-gray-600 mb-3">
              <strong>Subject:</strong> {email.subject}
            </div>
            
            <div className="text-sm text-gray-700 border-t pt-3 whitespace-pre-line line-clamp-3">
              {email.body}
            </div>
            
            {email.sentAt && (
              <div className="text-xs text-gray-500 mt-2">
                Sent: {new Date(email.sentAt).toLocaleString()}
              </div>
            )}
          </div>
        ))}
        
        {filteredEmails.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">No emails match your search criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmailList;