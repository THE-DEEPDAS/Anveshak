import React, { useState } from 'react';
import { Send, Loader, Search } from 'lucide-react';
import Button from '../ui/Button';
import { useAppContext } from '../../context/AppContext';
import { generateEmails, sendEmails } from '../../services/emailService';

const EmailGenerator: React.FC = () => {
  const { resume, setEmails, emails } = useAppContext();
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [generatedCount, setGeneratedCount] = useState(0);

  const handleGenerateEmails = async () => {
    if (!resume) {
      setError('No resume found. Please upload your resume first.');
      return;
    }

    setGenerating(true);
    setError(null);
    setSuccess(null);

    try {
      const generatedEmails = await generateEmails(resume.id!);
      setEmails(generatedEmails);
      setGeneratedCount(generatedEmails.length);
      setSuccess(`Successfully generated ${generatedEmails.length} personalized emails.`);
    } catch (err) {
      console.error('Error generating emails:', err);
      setError('Failed to generate emails. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  const handleSendEmails = async () => {
    if (!emails.length) {
      setError('No emails to send. Please generate emails first.');
      return;
    }

    setSending(true);
    setError(null);
    setSuccess(null);

    try {
      const result = await sendEmails(emails.map(email => email.id!));
      setSuccess(`Successfully sent ${result.sent} emails.`);
      
      // Update email statuses
      setEmails(emails.map(email => ({
        ...email,
        status: 'sent',
        sentAt: new Date()
      })));
    } catch (err) {
      console.error('Error sending emails:', err);
      setError('Failed to send emails. Please try again.');
    } finally {
      setSending(false);
    }
  };

  if (!resume) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="text-gray-600">Please upload your resume to generate emails.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Cold Email Generation</h2>
      
      <div className="space-y-6">
        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <div className="flex items-start">
            <Search className="h-5 w-5 text-blue-600 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-medium text-blue-800 mb-1">How it works</h3>
              <p className="text-sm text-blue-700">
                Our AI will analyze your skills and experience to identify relevant companies and generate personalized cold emails. You can review the emails before sending them.
              </p>
            </div>
          </div>
        </div>
        
        {error && (
          <div className="bg-red-50 text-red-800 p-3 rounded-md text-sm">
            {error}
          </div>
        )}
        
        {success && (
          <div className="bg-green-50 text-green-800 p-3 rounded-md text-sm">
            {success}
          </div>
        )}
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="primary"
            isLoading={generating}
            disabled={generating || !resume}
            leftIcon={generating ? undefined : <Search className="h-4 w-4" />}
            onClick={handleGenerateEmails}
            className="flex-1"
          >
            {generating ? 'Generating Emails...' : 'Generate Emails'}
          </Button>
          
          <Button
            variant="secondary"
            isLoading={sending}
            disabled={sending || !emails.length}
            leftIcon={sending ? undefined : <Send className="h-4 w-4" />}
            onClick={handleSendEmails}
            className="flex-1"
          >
            {sending ? 'Sending...' : `Send ${emails.length} Emails`}
          </Button>
        </div>
        
        {generating && (
          <div className="flex items-center justify-center p-4 border border-blue-100 bg-blue-50 rounded-md">
            <Loader className="h-5 w-5 text-blue-600 animate-spin mr-3" />
            <span className="text-blue-700">Searching for companies and generating personalized emails...</span>
          </div>
        )}
        
        {generatedCount > 0 && !generating && (
          <div className="text-sm text-gray-600">
            {generatedCount} emails are ready to be sent. View them in the Emails tab.
          </div>
        )}
      </div>
    </div>
  );
};

export default EmailGenerator;