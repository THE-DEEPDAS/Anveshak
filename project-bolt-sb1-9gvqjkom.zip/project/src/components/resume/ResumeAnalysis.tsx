import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Code, Briefcase, BookOpen, Check } from 'lucide-react';

const ResumeAnalysis: React.FC = () => {
  const { resume } = useAppContext();

  if (!resume) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Resume Analysis</h2>
      
      <div className="space-y-6">
        <div>
          <div className="flex items-center mb-3">
            <Code className="h-5 w-5 text-blue-600 mr-2" />
            <h3 className="text-lg font-medium text-gray-700">Skills</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {resume.skills.map((skill, index) => (
              <span 
                key={index}
                className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
        
        <div>
          <div className="flex items-center mb-3">
            <Briefcase className="h-5 w-5 text-purple-600 mr-2" />
            <h3 className="text-lg font-medium text-gray-700">Experience</h3>
          </div>
          <ul className="space-y-2">
            {resume.experience.map((exp, index) => (
              <li key={index} className="flex">
                <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                <span className="text-gray-700">{exp}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <div className="flex items-center mb-3">
            <BookOpen className="h-5 w-5 text-green-600 mr-2" />
            <h3 className="text-lg font-medium text-gray-700">Projects</h3>
          </div>
          <ul className="space-y-2">
            {resume.projects.map((project, index) => (
              <li key={index} className="flex">
                <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                <span className="text-gray-700">{project}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ResumeAnalysis;