import React, { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  id?: string;
  name?: string;
  email?: string;
}

interface Resume {
  id?: string;
  url?: string;
  skills: string[];
  experience: string[];
  projects: string[];
}

interface Email {
  id?: string;
  company: string;
  recipient: string;
  subject: string;
  body: string;
  status: 'draft' | 'sent' | 'failed';
  sentAt?: Date;
}

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  resume: Resume | null;
  setResume: (resume: Resume | null) => void;
  emails: Email[];
  setEmails: (emails: Email[]) => void;
  loading: boolean;
  setLoading: (loading: boolean) => void;
}

const defaultContext: AppContextType = {
  user: null,
  setUser: () => {},
  resume: null,
  setResume: () => {},
  emails: [],
  setEmails: () => {},
  loading: false,
  setLoading: () => {},
};

const AppContext = createContext<AppContextType>(defaultContext);

export const useAppContext = () => useContext(AppContext);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider = ({ children }: AppProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [resume, setResume] = useState<Resume | null>(null);
  const [emails, setEmails] = useState<Email[]>([]);
  const [loading, setLoading] = useState(false);

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        resume,
        setResume,
        emails,
        setEmails,
        loading,
        setLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};